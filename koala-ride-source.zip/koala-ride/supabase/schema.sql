-- KoalaRide starter schema. Apply in a new Supabase project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role text not null default 'passenger' check (role in ('passenger','driver','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.drivers (
  id uuid primary key references public.profiles(id) on delete cascade,
  abn text,
  vehicle_make text,
  vehicle_model text,
  vehicle_registration text,
  insurance_expiry date,
  accreditation_status text not null default 'pending',
  is_online boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.rides (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id),
  driver_id uuid references public.drivers(id),
  pickup_label text not null,
  destination_label text not null,
  pickup_lat double precision,
  pickup_lng double precision,
  destination_lat double precision,
  destination_lng double precision,
  scheduled_for timestamptz,
  status text not null default 'requested'
    check (status in ('requested','accepted','arriving','in_progress','completed','cancelled')),
  fare_aud numeric(10,2) not null default 0,
  promo_code text,
  created_at timestamptz not null default now()
);

create table if not exists public.driver_locations (
  driver_id uuid primary key references public.drivers(id) on delete cascade,
  latitude double precision not null,
  longitude double precision not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id),
  amount_aud numeric(10,2) not null,
  currency text not null default 'AUD',
  provider text not null default 'stripe',
  provider_payment_id text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create table if not exists public.promotions (
  code text primary key,
  percent_off numeric(5,2) not null check (percent_off > 0 and percent_off <= 100),
  active boolean not null default true,
  starts_at timestamptz,
  ends_at timestamptz,
  max_redemptions integer,
  redemptions integer not null default 0
);

create table if not exists public.driver_earnings (
  id uuid primary key default gen_random_uuid(),
  ride_id uuid not null references public.rides(id),
  driver_id uuid not null references public.drivers(id),
  gross_fare_aud numeric(10,2) not null,
  platform_fee_aud numeric(10,2) not null,
  driver_net_aud numeric(10,2) not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.drivers enable row level security;
alter table public.rides enable row level security;
alter table public.driver_locations enable row level security;
alter table public.payments enable row level security;
alter table public.promotions enable row level security;
alter table public.driver_earnings enable row level security;

-- Starter policies: users can see/update their own profile.
create policy "profile own read" on public.profiles for select using (auth.uid() = id);
create policy "profile own update" on public.profiles for update using (auth.uid() = id);
create policy "driver own read" on public.drivers for select using (auth.uid() = id);
create policy "ride passenger or assigned driver read" on public.rides for select
  using (auth.uid() = passenger_id or auth.uid() = driver_id);
create policy "passenger create own ride" on public.rides for insert
  with check (auth.uid() = passenger_id);
create policy "driver own location read" on public.driver_locations for select
  using (auth.uid() = driver_id);
create policy "driver own earnings read" on public.driver_earnings for select
  using (auth.uid() = driver_id);

-- IMPORTANT: add reviewed admin policies and secure server-side payment/dispatch
-- functions before production. Do not expose service-role keys in a mobile app.
