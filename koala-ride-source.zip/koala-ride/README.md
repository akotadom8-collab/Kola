# KoalaRide — cross-platform rideshare starter

KoalaRide is an Expo / React Native starter for an Australian Uber-style rideshare product.
It runs on Android and iOS and includes passenger, driver, trips and admin demo screens.

## Run it

1. Install Node.js (LTS) and Git.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start Expo:
   ```bash
   npx expo start
   ```
4. Install **Expo Go** on your Android or iPhone and scan the QR code. For iOS simulator / Android emulator, use the Expo shortcuts shown in the terminal.

## Included in this starter

- Passenger ride request flow and indicative AUD fare estimate
- Everyday, Comfort and XL vehicle options
- Demo promo code `KOALA10` (10% off)
- Scheduled ride entry
- Driver online/offline demo and earnings screen
- Trips list and device location / map preview
- Admin overview with sample metrics and driver list
- Supabase client setup and starter SQL schema

## Important: demo vs production

This is a runnable **prototype**, not a live ride-hailing marketplace. It does not yet dispatch real drivers, charge real cards, provide turn-by-turn navigation, or verify compliance documents. Demo trips, drivers, metrics and earnings are local sample data. The live-location subscription is a starter hook; it needs authenticated driver broadcasting and secure trip-channel authorization.

### Configure Supabase

1. Create a Supabase project.
2. In the SQL Editor, run `supabase/schema.sql`.
3. Copy `.env.example` to `.env` and set:
   - `EXPO_PUBLIC_SUPABASE_URL`
   - `EXPO_PUBLIC_SUPABASE_ANON_KEY`
4. Configure Auth, email/SMS verification, role assignment and reviewed RLS policies.
5. Never put the Supabase service-role key in the app.

### Maps

Add a Google Maps API key to `app.json` for Android map tiles. Configure the iOS Maps provider/API key and billing restrictions before release. Expo Location permission is requested at runtime.

### Payments

Use Stripe Connect (or another approved marketplace payment provider) for driver onboarding, payment collection, refunds, payouts and identity verification. Create PaymentIntents and Connect accounts on a trusted backend / serverless function. Never put secret payment keys in the mobile app. The current fare and payment screens are illustrative only.

### Before accepting real bookings in Australia

Get state-by-state advice on passenger transport / rideshare authorisations, driver accreditation, vehicle eligibility, CTP and commercial insurance, work health and safety, tax, GST, privacy, consumer law, payment handling and record keeping. Requirements vary by state and operating model. Verify current requirements with the relevant state regulator and qualified advisers. A driver ABN alone does not establish contractor status.

## Suggested production milestones

1. Authentication, phone verification and role-based access.
2. Driver onboarding and document review workflow.
3. Server-side trip matching, dispatch and realtime location.
4. Maps directions, ETA and distance-based fare calculation.
5. Stripe Connect payments, refunds and driver payouts.
6. Admin web portal with audit logs and support tools.
7. Security testing, accessibility, privacy review and app-store release.

## Project structure

- `App.js` — mobile prototype screens and demo interactions
- `src/supabase.js` — optional Supabase client
- `supabase/schema.sql` — starter database tables and basic RLS policies
- `app.json` — Expo app and location configuration
